<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>株式会社IIKA</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Keywords" Content="iika,コンサルティング,中国,留学,企業海外進出入,ビジネス支援,教育研修″>
<meta name="description" content="株式会社iikaは、グローバルコンサルティングファームとして、企業の海外進出、ECサービス、留学仲介、旅行プログラムなど、様々な分野・産業に対して海外進出戦略の策定、市場調査と分析、現地法規制の確認、競合他社の調査、パートナーシップ構築、販路拡大戦略、ローカリゼーション戦略など、あらゆるコンサルティングを提供しています。また、VTuber・3Dアニメーションの作成・運用・保守など、アウトソーシングサービスにも注力しています。">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="container">

<header class="l-header" id="l-header">
	<div class="btmArea">
		<div class="l-header__container">
			<h1 class="logo"><a href="index.html"><img class="js-swapOnSp" src="images/new/A2.png" alt="株式会社IIKA" data-src-sp="images/new/A2.png"><span lang="en"></span></a></h1>
		</div>
	</div>
	<div class="topArea">
		<div class="l-header__container">
			<div class="lang">
				<ul class="linkList">
					<li><a href="service3.html" lang="en">JP</a></li>
					<li><a href="service3-en.html" lang="en">EN</a></li>
					<li class="current"><a href="service3-cn.html">CN</a></li>
				</ul>
			</div>
		</div>
	</div>
</header>

<!--メインメニュー-->
<div id='menubar'>
	<nav id='menubar2'>
		<ul>
			<li><a href='index-cn.html'>主页</a></li>
			<li><a href=''>事业内容</a>
				<ul>
					<li><a href='service2-cn.html'>滑轮的制造/工厂代工/<br>零售批发</a></li>
					<li><a href='service3-cn.html'>商务咨询</a></li>
					<li><a href='service4-cn.html'>签证/移民</a></li>
					<li><a href='service5-cn.html'>留学</a></li>
				</ul>
			</li>
			<li><a href='company-cn.html'>公司简介</a></li>
			<!--<li><a href='faq-cn.html'>FAQ</a></li>-->
			<li><a href='contact-cn.html'>联系我们</a></li>
		</ul>
	</nav>
	<div class='menubar_lang'>
		<ul class='menubar_linkList'>
			<li><a href="service2.html" lang="en">JP</a></li>
			<li><a href="service2-en.html" lang="en">EN</a></li>
			<li class="menubar_current"><a href="service3-cn.html">CN</a></li>
		</ul>
	</div>
</div>

<div id='contents'>
<main>
<article>
<h2>滑轮及关联产品</h2>
<!--
<div class="list">
	<div>
	<figure><img src="images/service3.jpg" alt=""></figure>
	<h4>日本国内企業海外事業展開</h4>
	<p>日本国内企業海外事業展開</p>
	</div>
	<p class="btn"><a href="service_item_bandaoti.html">詳細を見る</a></p>
</div>
-->
<figure id="item-image">
<img src="images/english/sp/23.png" alt="" >
<img src="images/english/sp/24.png" alt="" >
<img src="images/english/sp/25.png" alt="" >
<img src="images/english/sp/26.png" alt="" >
<img src="images/english/sp/27.png" alt="" >
<img src="images/english/sp/28.png" alt="" >
<img src="images/english/sp/29.png" alt="" >
<img src="images/english/sp/20.png" alt="" >
<img src="images/english/sp/21.png" alt="" >
</figure>
<!--/.list-container-->
</article>
</main>
</div>
<!--/#contents-->
<script type="text/javascript" src="js/foot-cn.js"></script>
</div>
<!--/#container-->
<!--jQueryの読み込み-->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!--スライドショー（slick）-->
<!--<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>-->
<script type="text/javascript" src="js/slick.min.js"></script>
<script type="text/javascript" src="js/slick.js"></script>
<!--biz56用のスクリプト-->
<script src="js/main.js"></script>
<!--ハンバーガーボタン（開閉操作のボタン）-->
<div id="menubar_hdr"></div>
<!--ページの上部へ戻るボタン-->
<div class="pagetop"><a href="#"><i class="fas fa-angle-double-up"></i></a></div>
</body>
</html>